<!-- jQuery -->
    <script src="<?php echo URL; ?>js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo URL; ?>js/bootstrap.min.js"></script>

    <!-- Scrolling Nav JavaScript -->
    <script src="<?php echo URL; ?>js/jquery.easing.min.js"></script>
    <script src="<?php echo URL; ?>js/scrolling-nav.js"></script>

</body>

</html>
