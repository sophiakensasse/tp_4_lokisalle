<?php

//ici on appelle notre connexion à la BDD//////////////
include("inc/back/init.inc.php");
///////////////////////////////////////////////////////



//ON APPELLE ICI LE HEADER ET LE MENU//////////////////
include("inc/back/header.inc.php");
include("inc/back/nav.inc.php");
?>

   <!---MON WRAPPER DE LA PAGE--->
    <div id="page-wrapper">

        <div class="container-fluid">

        </div> <!--FIN DE CONTAINER-FUID--->
    </div><!--FIN DE DIV PAGE WRAPPER--->

</div>
<!-- /#wrapper PAGE + NAV -->


<?php
include("inc/back/footer.inc.php");